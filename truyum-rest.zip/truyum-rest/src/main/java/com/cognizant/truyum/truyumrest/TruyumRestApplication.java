package com.cognizant.truyum.truyumrest;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TruyumRestApplication {

	public static void main(String[] args) {
		SpringApplication.run(TruyumRestApplication.class, args);
	}

}
