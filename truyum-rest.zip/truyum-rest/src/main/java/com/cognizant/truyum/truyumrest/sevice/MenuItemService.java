package com.cognizant.truyum.truyumrest.sevice;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cognizant.truyum.truyumrest.dao.MenuItemDao;
import com.cognizant.truyum.truyumrest.exception.MenuItemNotFoundException;
import com.cognizant.truyum.truyumrest.model.MenuItem;

@Service
public class MenuItemService {
 
	@Autowired
    private MenuItemDao menuItemDao;

	public List<MenuItem> getMenuItemListCustomer() {
		// TODO Auto-generated method stub
		return menuItemDao.getMenuItemListCustomer();
	}

	public void modifyMenuItem(MenuItem menuItem) {
		menuItemDao.modifyMenuItem(menuItem);

	}

	public MenuItem getMenuItem(long id) throws MenuItemNotFoundException {
		return menuItemDao.getMenuItem(id);
	}

}
