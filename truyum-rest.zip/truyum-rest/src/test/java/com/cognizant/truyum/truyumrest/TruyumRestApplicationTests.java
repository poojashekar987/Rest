package com.cognizant.truyum.truyumrest;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TruyumRestApplicationTests {

	@Test
	void contextLoads() {
	}

}
