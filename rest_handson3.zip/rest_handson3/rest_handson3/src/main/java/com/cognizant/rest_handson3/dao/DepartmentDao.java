package com.cognizant.rest_handson3.dao;

import java.util.ArrayList;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.stereotype.Component;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.cognizant.rest_handson3.model.Department;
import com.cognizant.rest_handson3.model.Employee;
import com.cognizant.rest_handson3.service.EmployeeNotFoundException;
import com.cognizant.rest_handson3.service.EmployeeService;

@Component
public class DepartmentDao {

	private static ArrayList<Department> DEPARTMENT_LIST;
	
	public DepartmentDao() {
		ApplicationContext context = new ClassPathXmlApplicationContext("Employee.xml");
		DEPARTMENT_LIST = (ArrayList<Department>) context.getBean("departmentList");

	}
	

	public ArrayList<Department> getAllDepartments() {
		// TODO Auto-generated method stub
		
		return DEPARTMENT_LIST;
	}
	
}
